import React, { useCallback } from "react";
import CustomDashboard from "../components/CustomDashboard";
import { useDispatch } from "react-redux";
import {setArticle} from "../global/slices/articleSlice";
import {setCategory} from "../global/slices/categorySlice";
import {setMasterCategory} from "../global/slices/masterCategorySlice";
import {setClothType} from "../global/slices/clothTypeSlice";

export default function BoysDashboard(){
    
  const dispatch = useDispatch();
    const firstSection = [
      { name: "T-Shirts",masterCategory:"Apparel", subCategory: "Topwear", articleType: "tshirts",  },
      { name: "Shirts", masterCategory:"Apparel", subCategory: "Topwear", articleType: "shirts",  },
      { name: "Jeans", masterCategory:"Apparel", subCategory: "Bottomwear", articleType: "jeans",  },
      { name: "Trousers", masterCategory:"Apparel", subCategory: "Bottomwear", articleType: "trousers",  },
      { name: "Shorts", masterCategory:"Apparel", subCategory: "Bottomwear", articleType: "shorts",  },
      { name: "Shoes", masterCategory:"Apparel", subCategory: "Footwear", articleType: "shoes",  }
    ];
  
    const secondSection = [
      { name: "Casual Wear", masterCategory:"Apparel", usage:"Casual"  },
      { name: "Office Wear", masterCategory:"Apparel", usage:"Formal"},
      { name: "Sports Wear", masterCategory:"Apparel", usage:"Sports"},
      {name:"Ethnic Wear", masterCategory:"Apparel", usage:"Ethnic"}    
    ];
  
    const handleClick = useCallback ((masterCategory, subCategory, articleType, usage)=>{
      dispatch(setMasterCategory(masterCategory));
      dispatch(setCategory(subCategory));
      dispatch(setArticle(articleType));
      dispatch(setClothType(usage));
    },[dispatch]);

  return (
    <CustomDashboard firstSec={firstSection} secondSec={secondSection} 
    image1={"https://im.ge/i/boys-first-section-eeyYe4"} onClick={handleClick}/>
  );
}